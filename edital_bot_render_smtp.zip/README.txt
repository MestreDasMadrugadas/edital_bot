Instruções:
1. Substitua a senha de app em utils.py
2. Rode localmente com Flask
3. Teste o endpoint /webhook
4. Suba no Render com gunicorn app:app